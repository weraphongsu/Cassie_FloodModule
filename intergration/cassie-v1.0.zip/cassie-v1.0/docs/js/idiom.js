function toEnglish(){
    $('body').removeClass('pt');
    $('body').addClass('en');
}   

function toPortuguese(){
    $('body').removeClass('en');
    $('body').addClass('pt');
}