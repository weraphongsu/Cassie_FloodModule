function removeAlert(){
    $('div').addClass('none');
    $('nav').removeClass('dev-alert-ative');
}  