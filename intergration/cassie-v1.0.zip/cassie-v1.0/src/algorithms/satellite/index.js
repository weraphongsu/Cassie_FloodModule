import Landsat from './landsat';
import LandsatTOA from './landsatToa'
import Sentinel from './sentinel';

export default { Landsat, LandsatTOA, Sentinel };