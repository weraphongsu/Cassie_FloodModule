import { Types, Actions } from './header'

const root = function* () { }

export default root